This package contains third-party software components governed by the license(s) indicated below:
---------


