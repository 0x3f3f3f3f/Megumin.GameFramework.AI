using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Megumin.GameFramework.AI.StateMachine
{
    public class StateMachine
    {

    }
}
