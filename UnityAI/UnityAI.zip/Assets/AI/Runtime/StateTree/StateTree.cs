using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Megumin.GameFramework.AI.StateTree
{
    public class StateTree
    {
        
    }
}
